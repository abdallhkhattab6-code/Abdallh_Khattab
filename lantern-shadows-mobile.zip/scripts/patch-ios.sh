#!/bin/bash
# Run on a Mac after `npx cap add ios`: landscape only, hide the status bar.
set -e
P=ios/App/App/Info.plist
B=/usr/libexec/PlistBuddy
for KEY in UISupportedInterfaceOrientations "UISupportedInterfaceOrientations~ipad"; do
  $B -c "Delete :$KEY" "$P" 2>/dev/null || true
  $B -c "Add :$KEY array" "$P"
  $B -c "Add :$KEY:0 string UIInterfaceOrientationLandscapeLeft" "$P"
  $B -c "Add :$KEY:1 string UIInterfaceOrientationLandscapeRight" "$P"
done
$B -c "Add :UIStatusBarHidden bool true" "$P" 2>/dev/null || $B -c "Set :UIStatusBarHidden true" "$P"
$B -c "Add :UIViewControllerBasedStatusBarAppearance bool false" "$P" 2>/dev/null || $B -c "Set :UIViewControllerBasedStatusBarAppearance false" "$P"
echo "iOS project patched."
